import Spinner from 'react-bootstrap/Spinner';

export function Loading() {
  return <Spinner animation="grow" className='loading'/>;
}
